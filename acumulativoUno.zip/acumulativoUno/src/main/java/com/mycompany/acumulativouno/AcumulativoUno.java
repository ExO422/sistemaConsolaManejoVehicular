package com.mycompany.acumulativouno;

import java.util.Scanner;

public class AcumulativoUno {
    public static void main(String[] args) {
        Scanner key = new Scanner(System.in);
        vehiculo vehi1 = new vehiculo();
        while(true){
        System.out.printf("%n%n---Acumulado #1 ---%n%n%n");
        System.out.println("---------------------------------");
        System.out.println("--Sistema de gestion vehicular --");
        System.out.println("---------------------------------");
        System.out.println("------------- Menu --------------");
        System.out.println("Seleccione #1 para especificar la marca --");
        System.out.println("Seleccione #2 para especificar el modelo --");
        System.out.println("Seleccione #3 para especificar el annio --");
        System.out.println("Seleccione #4 para especificar el precio --");
        System.out.println("Seleccione #5 para especificar la depreciacion --");
        System.out.println("----");
        System.out.println("Seleccione #6 para visualizar los datos del vehiculo");
        System.out.println("----");
        System.out.println("Ingrese la opcion que ud desea:");
        int op = key.nextInt();
        key.nextLine();
        switch(op){
            case 1 ->{  
                System.out.println("Favor especifique la marca");
                String marca = key.nextLine();
                vehi1.setmarca(marca);
                break;}
            case 2 ->{  
                System.out.println("Favor especifique el modelo");
                String modelo = key.nextLine();
                vehi1.setmodelo(modelo);
                break;}
            case 3 ->{  
                System.out.println("Favor especifique el año del vehiculo");
                int annio = key.nextInt();
                vehi1.setannio(annio);
                break;}
            case 4 ->{  
                System.out.println("Favor especifique el precio del vehiculo");
                double precio = key.nextDouble();
                vehi1.setprecio(precio);
                break;}
            case 5 ->{  
                System.out.println("Favor especifique el % de depreciacion del vehiculo");
                double  depreci = key.nextDouble();
                vehi1.setdepreci(depreci);
                break;}
            case 6 ->{
                System.out.printf("%nLos datos de su vehiculo son:"
                        + "%nMarca: %s"
                        + "%nModelo: %s"
                        + "%nAño: %d"
                        + "%nPrecio: L.%.2f"
                        + "%nDepreciacion: %.2f%%"
                        ,vehi1.getmarca(),vehi1.getmodelo(),vehi1.getannio(), vehi1.getprecio(),vehi1.getdepreci());  
                System.out.printf("%nPresione Enter para continuar");
                key.nextLine();
                break;}
            default-> System.out.println("Opcion no valida");
        }
                
        }                   
    }

    
}

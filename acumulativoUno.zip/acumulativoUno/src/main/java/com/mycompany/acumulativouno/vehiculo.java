package com.mycompany.acumulativouno;

public class vehiculo {
    //Atributos
        String marca,modelo;
        int annio;
        double precio, depreci;
        
    //Metodos
        public vehiculo(){}
        
        public vehiculo(String marca, String modelo, int annio, double precio, double depreci){
            this.marca=marca;
            this.modelo=modelo;
            this.annio=annio;
            this.precio=precio;
            this.depreci=depreci;
        }
    //Set y get
        public void setmarca(String marca){
            this.marca=marca;
        }
        public String getmarca(){
            return marca;
        }
        public void setmodelo(String modelo){
            this.modelo=modelo;
        }
        public String getmodelo(){
            return modelo;
        }
        public void setannio(int annio){
            this.annio=annio;
        }
        public int getannio(){
            return annio;
        }
        public void setprecio(double precio){
            this.precio=precio;
        }
        public double getprecio(){
            return precio;
        }
        public void setdepreci(double depreci){
            this.depreci=depreci;
        }
        public double getdepreci(){
            return depreci;
        }
}
